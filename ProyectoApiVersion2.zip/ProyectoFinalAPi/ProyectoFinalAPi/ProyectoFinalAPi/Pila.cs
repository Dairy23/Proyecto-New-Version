﻿using System.Collections.Generic;
using System.Linq;
using ProyectoFinalAPi.Models;
using Microsoft.AspNetCore.Routing;
using NUnit.Framework;
using System.Text.Json;
using System.Collections.Generic;
using System;
using ProyectoFinalAPi;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.OpenApi.Models;

namespace ProyectoFinalAPi
{
    public class Pila<T>
    {
        private Stack<T> elementos = new Stack<T>();

        public void Apilar(T elemento)
        {
            elementos.Push(elemento);
        }

        public T Desapilar()
        {
            return elementos.Pop();
        }

        public T Peek()
        {
            return elementos.Peek();
        }

        public List<T> ObtenerTodos(Func<T, bool> predicado)
        {
            return elementos.Where(predicado).ToList();
        }

        public int Count
        {
            get { return elementos.Count; }
        }

        public List<T> ConsultarMovimientos()
        {
            return new List<T>(elementos);
        }
    }
}