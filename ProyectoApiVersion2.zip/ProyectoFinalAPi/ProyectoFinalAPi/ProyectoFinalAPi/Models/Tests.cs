﻿using Microsoft.AspNetCore.Routing;
using NUnit.Framework;
using ProyectoFinalAPi.Models;
using System.Text.Json;
using System.Collections.Generic;
using System;
using ProyectoFinalAPi;

[TestFixture]
public class test
{
    [Test]
    public void TestInsertar()
    {
        // Arrange
        ArbolBinarioBusqueda arbol = new ArbolBinarioBusqueda();

        // Act
        arbol.Insertar(5);
        arbol.Insertar(3);
        arbol.Insertar(7);

        // Assert
        Assert.IsTrue(arbol.Buscar(5));
        Assert.IsTrue(arbol.Buscar(3));
        Assert.IsTrue(arbol.Buscar(7));
        Assert.IsFalse(arbol.Buscar(10));
    }
}