﻿using Microsoft.AspNetCore.Routing;
using NUnit.Framework;
using ProyectoFinalAPi.Models;
using System.Text.Json;
using System.Collections.Generic;
using System;
using ProyectoFinalAPi;

//Dairy Pernillo 
//Programacion 
//Proyecto Final. 

namespace ProyectoFinalAPi.Models
{
    public class ListaEnlazada
    {


        public Nodo inicio;
        public void Add(TarjetaCredito tarjeta)
        {
            Nodo nuevoNodo = new Nodo(tarjeta);
            nuevoNodo.Siguiente = inicio;
            inicio = nuevoNodo;
        }


        public void AddRange(IEnumerable<TarjetaCredito> tarjetas)
        {
            foreach (var tarjeta in tarjetas)
            {
                Add(tarjeta);
            }
        }

        public void Insertar(TarjetaCredito tarjeta)
            {
                try
                {
                    Add(tarjeta);
                }
                catch (Exception ex)
                {
                    throw new Exception("Error al insertar en la lista enlazada.", ex);
                }
            }
            public double ConsultarSaldo(int numeroTarjeta)
        {
            Nodo actual = inicio;
            while (actual != null)
            {
                if (actual.Tarjeta.NumeroTarjeta == numeroTarjeta)
                    return actual.Tarjeta.Saldo;
                actual = actual.Siguiente;
            }
            return -1; // Si no se encuentra la tarjeta
        }
        public void CambiarPIN(int numeroTarjeta, int nuevoPIN)
        {
            Nodo actual = inicio;
            while (actual != null)
            {
                if (actual.Tarjeta.NumeroTarjeta == numeroTarjeta)
                {
                    actual.Tarjeta.PIN = nuevoPIN;
                    return;
                }
                actual = actual.Siguiente;
            }
        }

        public void ActualizarSaldo(int numeroTarjeta, double nuevoSaldo)
        {
            Nodo nodo = Buscar(numeroTarjeta);
            if (nodo != null)
            {
                nodo.Tarjeta.Saldo = nuevoSaldo; // Aquí está la corrección
            }
        }

        public Nodo Buscar(int numeroTarjeta)
        {
            Nodo actual = inicio;
            while (actual != null)
            {
                if (actual.Tarjeta.NumeroTarjeta == numeroTarjeta)
                {
                    return actual;
                }
                actual = actual.Siguiente;
            }
            return null; // Si no se encuentra la tarjeta
        }

        public class Nodo
        {
            public TarjetaCredito Tarjeta { get; }
            public Nodo Siguiente { get; set; }

            public Nodo(TarjetaCredito tarjeta)
            {
                Tarjeta = tarjeta;
            }
        }
    }
}
