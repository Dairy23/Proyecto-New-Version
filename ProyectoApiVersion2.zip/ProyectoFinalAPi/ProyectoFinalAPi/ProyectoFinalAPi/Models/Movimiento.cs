﻿using Microsoft.AspNetCore.Routing;
using NUnit.Framework;
using ProyectoFinalAPi.Models;
using System.Text.Json;
using System.Collections.Generic;
using System;
using ProyectoFinalAPi;

namespace ProyectoFinalAPi.Models
{
    public class Movimiento
    {
        public int NumeroTarjeta { get; set; }
        public string Tipo { get; set; }
        public double Monto { get; set; }
    }
}