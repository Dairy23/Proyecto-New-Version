﻿using Microsoft.AspNetCore.Routing;
using NUnit.Framework;
using ProyectoFinalAPi.Models;
using System.Text.Json;
using System.Collections.Generic;
using System;
using ProyectoFinalAPi;

namespace ProyectoFinalAPi.Models
{
    public class WeatherForecast
    {
        public DateTime Date { get; set; }

        public int TemperatureC { get; set; }

        public int TemperatureF => 32 + (int)(TemperatureC / 0.5556);

        public string Summary { get; set; }
    }
}