﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;
using Microsoft.AspNetCore.Mvc;
using ProyectoFinalAPi.Models;
using ProyectoFinalAPi;
using System;
using System.Collections.Generic;

[Route("api/[controller]")]
[ApiController]
public class BloqueoTemporalController : ControllerBase
{
    public readonly ArbolBinarioBusqueda arbolBloqueos;
    private readonly JSON _json;
    public readonly ArbolBinarioBusqueda arbolBinario;
    private readonly List<TarjetaCredito> tarjetas = new List<TarjetaCredito>();
    public BloqueoTemporalController(ArbolBinarioBusqueda arbolBinario1, ArbolBinarioBusqueda arbolBinario2, JSON json)
    {
        this.arbolBloqueos = arbolBinario1;
        this.arbolBinario = arbolBinario2;
        _json = json;
        Initialize();
    }

    private void Initialize()
    {
        try
        {
            string jsonFilePath = "misTarjetas.json"; // Nombre del archivo JSON
            var tarjetasDesdeJson = _json.CargarTarjetasDesdeJSON(jsonFilePath);
            tarjetas.AddRange(tarjetasDesdeJson);  // Agrega las tarjetas cargadas a la lista existente
        }
        catch (Exception ex)
        {
            // Manejar la excepción aquí, si es necesario
            Console.WriteLine($"Error al inicializar tarjetas de crédito: {ex.Message}");
        }
    }


    [HttpPost("bloquear")]
    public IActionResult BloquearTarjeta([FromBody] BloqueoTemporal bloqueo)
    {
        try
        {
            arbolBloqueos.Insertar(bloqueo.NumeroTarjeta);
            return Ok();
        }
        catch (Exception ex)
        {
            return StatusCode(500, "Se produjo un error al bloquear la tarjeta.");
        }
    }

    [HttpPost("desbloquear")]
    public IActionResult DesbloquearTarjeta([FromBody] BloqueoTemporal bloqueo)
    {
        try
        {
            arbolBloqueos.Eliminar(bloqueo.NumeroTarjeta);
            return Ok();
        }
        catch (Exception ex)
        {
            return StatusCode(500, "Se produjo un error al desbloquear la tarjeta.");
        }
    }

    [HttpDelete("{valor}")]
    public IActionResult EliminarValor(int valor)
    {
        try
        {
            arbolBinario.Eliminar(valor);
            return Ok("Valor eliminado correctamente.");
        }
        catch (Exception ex)
        {
            return StatusCode(500, "Se produjo un error al eliminar el valor del árbol binario.");
        }
    }
}

    public class BloqueoTemporal
{
    public int NumeroTarjeta { get; set; }
}