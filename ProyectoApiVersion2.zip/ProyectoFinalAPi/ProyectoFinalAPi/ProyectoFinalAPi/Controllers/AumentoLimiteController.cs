﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;
using Microsoft.AspNetCore.Mvc;
using ProyectoFinalAPi.Models;
using ProyectoFinalAPi;
using System;
using System.Collections.Generic;

[Route("api/[controller]")]
[ApiController]
public class AumentoLimiteController : ControllerBase
{
    private readonly Pila<SolicitudAumento> pilaSolicitudes;
    private readonly JSON _json;
    private readonly List<TarjetaCredito> tarjetas = new List<TarjetaCredito>();

    public AumentoLimiteController(Pila<SolicitudAumento> pilaSolicitudes, JSON json)
    {
        this.pilaSolicitudes = pilaSolicitudes;
        _json = json;
        Initialize();
    }

    private void Initialize()
    {
        try
        {
            string jsonFilePath = "misTarjetas.json"; // Nombre del archivo JSON
            var tarjetasDesdeJson = _json.CargarTarjetasDesdeJSON(jsonFilePath);
            tarjetas.AddRange(tarjetasDesdeJson);  // Agrega las tarjetas cargadas a la lista existente
        }
        catch (Exception ex)
        {
            // Manejar la excepción aquí, si es necesario
            Console.WriteLine($"Error al inicializar tarjetas de crédito: {ex.Message}");
        }
    }
    // Método para procesar las solicitudes de aumento de límite
    [HttpPost("procesar")]
    public IActionResult Procesar()
    {
        try
        {
            if (pilaSolicitudes.Count == 0)
            {
                return BadRequest("No hay solicitudes de aumento de límite para procesar.");
            }

            var solicitud = pilaSolicitudes.Desapilar();
            var tarjeta = tarjetas.Find(t => t.NumeroTarjeta == solicitud.NumeroTarjeta);
            if (tarjeta != null)
            {
                tarjeta.Limite = solicitud.NuevoLimite;
                return Ok("Solicitud de aumento de límite procesada correctamente.");
            }
            else
            {
                return NotFound("No se encontró la tarjeta de crédito.");
            }
        }
        catch (Exception ex)
        {
            return StatusCode(500, "Se produjo un error al procesar las solicitudes de aumento de límite.");
        }
    }
}