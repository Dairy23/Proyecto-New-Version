﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;
using Microsoft.AspNetCore.Mvc;
using ProyectoFinalAPi.Models;
using ProyectoFinalAPi;
using System;
using System.Collections.Generic;

[Route("api/[controller]")]
[ApiController]
public class CambioPINController : ControllerBase
{
    private readonly ListaEnlazada _listaTarjetas;
    private readonly JSON _json;
    private readonly List<TarjetaCredito> tarjetas = new List<TarjetaCredito>();


    public CambioPINController(ListaEnlazada listaTarjetas, JSON json)
{
       this._listaTarjetas = listaTarjetas;
       _json = json;
       Initialize();
}
    private void Initialize()
    {
        try
        {
            string jsonFilePath = "misTarjetas.json"; // Nombre del archivo JSON
            var tarjetasDesdeJson = _json.CargarTarjetasDesdeJSON(jsonFilePath);
            _listaTarjetas.AddRange(tarjetasDesdeJson);  // Agrega las tarjetas cargadas a la lista enlazada
        }
        catch (Exception ex)
        {
            // Manejar la excepción aquí, si es necesario
            Console.WriteLine($"Error al inicializar tarjetas de crédito: {ex.Message}");
        }
    }


    [HttpPost("{numeroTarjeta}")]
    public IActionResult CambiarPIN(int numeroTarjeta, [FromBody] int nuevoPIN)
    {
        try
        {
            // Validación manual de los datos de entrada
            if (nuevoPIN.ToString().Length != 4)
            {
                return BadRequest("El nuevo PIN debe tener 4 dígitos.");
            }

            _listaTarjetas.CambiarPIN(numeroTarjeta, nuevoPIN);
            return Ok("PIN cambiado correctamente.");
        }
        catch (Exception ex)
        {
            return StatusCode(500, "Se produjo un error al cambiar el PIN de la tarjeta.");
        }
    }
}


