﻿using Microsoft.AspNetCore.Routing;
using NUnit.Framework;
using ProyectoFinalAPi.Models;
using System.Text.Json;
using System.Collections.Generic;
using System;
using ProyectoFinalAPi;

//Dairy Pernillo 
//Programacion 
//Proyecto Final. 

namespace ProyectoFinalAPi.Models
{
    public class TarjetaCredito
    {
        public int NumeroTarjeta { get; set; }
        public double Saldo { get; set; }
        public double Limite { get; set; }  // Agrega esta línea
        public int PIN { get; set; }
        public string HashContraseña { get; set; }
        public string Salt { get; set; }

        // Método para almacenar de manera segura la contraseña utilizando técnicas de hashing y salting
        public void AlmacenarContraseña(string contraseña)
        {
            Salt = GenerarSalt();
            HashContraseña = CalcularHash(contraseña, Salt);
        }

        // Método para verificar si la contraseña proporcionada coincide con la almacenada
        public bool VerificarContraseña(string contraseña)
        {
            string hashEntrante = CalcularHash(contraseña, Salt);
            return hashEntrante == HashContraseña;
        }

        // Método para generar un salt aleatorio
        private string GenerarSalt()
        {
            // Implementa la generación de un salt aleatorio
            return "salt_aleatorio";
        }

        // Método para calcular el hash de la contraseña utilizando el salt
        private string CalcularHash(string contraseña, string salt)
        {
            // Implementa el cálculo del hash utilizando el algoritmo adecuado (por ejemplo, SHA-256)
            return "hash_calculado";
        }
    }
}