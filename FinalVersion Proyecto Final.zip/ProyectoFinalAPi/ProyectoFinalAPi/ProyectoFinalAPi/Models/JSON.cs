﻿using Microsoft.AspNetCore.Routing;
using NUnit.Framework;
using ProyectoFinalAPi.Models;
using System.Text.Json;
using System.Collections.Generic;
using System;
using ProyectoFinalAPi;

namespace ProyectoFinalAPi.Models
{

    public class JSON
    {
        public List<TarjetaCredito> CargarTarjetasDesdeJSON(string jsonFilePath)
        {
            if (!System.IO.File.Exists(jsonFilePath))
            {
                throw new FileNotFoundException("El archivo " + jsonFilePath + " no se encontró.");
            }
            string jsonContent = System.IO.File.ReadAllText(jsonFilePath);
            List<TarjetaCredito> tarjetas = JsonSerializer.Deserialize<List<TarjetaCredito>>(jsonContent);
            return tarjetas;
        }
    }
}