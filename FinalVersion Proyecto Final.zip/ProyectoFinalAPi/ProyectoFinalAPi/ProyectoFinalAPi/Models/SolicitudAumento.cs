﻿using Microsoft.AspNetCore.Routing;
using NUnit.Framework;
using ProyectoFinalAPi.Models;
using System.Text.Json;
using System.Collections.Generic;
using System;
using ProyectoFinalAPi;

namespace ProyectoFinalAPi.Models
{
    public class SolicitudAumento
    {
        public int NumeroTarjeta { get; set; }
        public double NuevoLimite { get; set; }
    }
}