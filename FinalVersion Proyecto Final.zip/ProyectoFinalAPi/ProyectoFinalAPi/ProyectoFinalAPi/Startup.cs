﻿using System.Collections.Generic;
using System.Linq;
using ProyectoFinalAPi.Models;
using Microsoft.AspNetCore.Routing;
using NUnit.Framework;
using System.Text.Json;
using System.Collections.Generic;
using System;
using ProyectoFinalAPi;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.OpenApi.Models;


//Dairy Pernillo 
//Programacion 
//Proyecto Final. 

public class Startup
{
    public void ConfigureServices(IServiceCollection services)
    {
        services.AddSingleton<JSON>();
        services.AddTransient<ProyectoFinalAPi.Models.JSON>();
        services.AddSingleton<ListaEnlazada>();
        services.AddSingleton<ArbolBinarioBusqueda>(); // Registrar ArbolBinarioBusqueda como un servicio singleton
        services.AddMvc();
        services.AddControllers();
        services.AddSingleton<Pila<SolicitudAumento>>();

        // Configuración de Swagger
        services.AddSwaggerGen(options =>
        {
            options.SwaggerDoc("v1", new OpenApiInfo { Title = "Tarjeta de Credito", Version = "v1" });
        });
    }

    public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
    {

        if (env.IsDevelopment())
        {
            app.UseDeveloperExceptionPage();
        }

        app.UseHttpsRedirection();

        app.UseRouting();

        app.UseAuthorization();

        // Habilitar Swagger y SwaggerUI
        app.UseSwagger();
        app.UseSwaggerUI(options =>
        {
            options.SwaggerEndpoint("/swagger/v1/swagger.json", "Tarjeta de Credito");
        });

        app.UseEndpoints(endpoints =>
        {
            endpoints.MapControllers();
        });
    }
}