﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;
using Microsoft.AspNetCore.Mvc;
using ProyectoFinalAPi.Models;
using ProyectoFinalAPi;
using System;
using System.Collections.Generic;

public class InitialLoadController : ControllerBase
{
    private ListaEnlazada _listaEnlazada;
    private readonly JSON _json;
    public InitialLoadController(JSON json)
    {
        _json = json;
        _listaEnlazada = Initialize();
    }
    private ListaEnlazada Initialize()
    {
        ListaEnlazada listaEnlazada = new ListaEnlazada();
        try
        {
            string jsonFilePath = "misTarjetas.json"; // Nombre del archivo JSON
            var tarjetasDesdeJson = _json.CargarTarjetasDesdeJSON(jsonFilePath);
            listaEnlazada.AddRange(tarjetasDesdeJson);  // Agrega las tarjetas cargadas a la lista enlazada
        }
        catch (Exception ex)
        {
            // Manejar la excepción aquí, si es necesario
            Console.WriteLine($"Error al inicializar tarjetas de crédito: {ex.Message}");
        }
        return listaEnlazada;
    }

    [HttpPost("load")]
    public IActionResult LoadInitialData()
    {
        try
        {
            string jsonFilePath = "misTarjetas.json"; // Nombre del archivo JSON

            if (!System.IO.File.Exists(jsonFilePath))
            {
                return StatusCode(500, "El archivo datos_tarjetas.json no se encontró en la ruta especificada.");
            }
            string jsonContent = System.IO.File.ReadAllText(jsonFilePath);
            List<TarjetaCredito> tarjetas = JsonSerializer.Deserialize<List<TarjetaCredito>>(jsonContent);

            // Aquí puedes agregar las tarjetas a tus estructuras de datos
            _listaEnlazada.AddRange(tarjetas);

            return Ok("Datos iniciales cargados con éxito.");
        }
        catch (Exception ex)
        {
            return StatusCode(500, $"Error al cargar los datos iniciales: {ex.Message}");
        }
    }
}