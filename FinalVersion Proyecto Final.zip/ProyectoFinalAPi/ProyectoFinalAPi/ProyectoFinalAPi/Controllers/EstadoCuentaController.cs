﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;
using Microsoft.AspNetCore.Mvc;
using ProyectoFinalAPi.Models;
using ProyectoFinalAPi;
using System;
using System.Collections.Generic;

[Route("api/[controller]")]
[ApiController]
public class EstadoCuentaController : ControllerBase
{
    private readonly ArbolBinarioBusqueda _arbolEstadosCuenta;
    private readonly JSON _json;
    private readonly List<TarjetaCredito> tarjetas = new List<TarjetaCredito>();
    public EstadoCuentaController(ArbolBinarioBusqueda arbolEstadosCuenta, JSON json)
    {
        this._arbolEstadosCuenta = arbolEstadosCuenta;
        _json = json;
        Initialize();
    }

    private void Initialize()
    {
        try
        {
            string jsonFilePath = "misTarjetas.json"; // Nombre del archivo JSON
            var tarjetasDesdeJson = _json.CargarTarjetasDesdeJSON(jsonFilePath);
            tarjetas.AddRange(tarjetasDesdeJson);  // Agrega las tarjetas cargadas a la lista existente
        }
        catch (Exception ex)
        {
            // Manejar la excepción aquí, si es necesario
            Console.WriteLine($"Se produjo un error al generar el estado de cuenta: {ex.Message}");
        }
    }

    [HttpGet("{numeroTarjeta}")]
    public IActionResult GenerarEstadoCuenta(int numeroTarjeta)
    {
        try
        {
            var estadoCuenta = _arbolEstadosCuenta.Buscar(numeroTarjeta);
            if (estadoCuenta == null)
                return NotFound();
            return Ok(estadoCuenta);
        }
        catch (Exception ex)
        {
            return StatusCode(500, "Se produjo un error al generar el estado de cuenta.");
        }
    }
}
