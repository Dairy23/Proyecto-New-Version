﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;
using Microsoft.AspNetCore.Mvc;
using ProyectoFinalAPi.Models;
using ProyectoFinalAPi;
using System;
using System.Collections.Generic;

namespace ProyectoFinalAPi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class NotificacionesController : ControllerBase
    {
        private readonly Cola<Notificacion> _colaNotificaciones;
        private readonly JSON _json;
        private readonly List<TarjetaCredito> tarjetas = new List<TarjetaCredito>();
        public NotificacionesController(Cola<Notificacion> colaNotificaciones, JSON json)
        {
            this._colaNotificaciones = colaNotificaciones;
            _json = json;
            Initialize();
        }
        private void Initialize()
        {
            try
            {
                string jsonFilePath = "misTarjetas.json"; // Nombre del archivo JSON
                var tarjetasDesdeJson = _json.CargarTarjetasDesdeJSON(jsonFilePath);
                tarjetas.AddRange(tarjetasDesdeJson);  // Agrega las tarjetas cargadas a la lista existente
            }
            catch (Exception ex)
            {
                // Manejar la excepción aquí, si es necesario
                Console.WriteLine($"Error al inicializar tarjetas de crédito: {ex.Message}");
            }
        }

        [HttpPost]
        public IActionResult EnviarNotificacion([FromBody] Notificacion notificacion)
        {
            try
            {
                _colaNotificaciones.Encolar(notificacion);
                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, "Se produjo un error al enviar la notificación.");
            }
        }
        // Método para procesar las notificaciones en la cola
        [HttpPost("procesar")]
        public IActionResult ProcesarNotificacion()
        {
            try
            {
                if (_colaNotificaciones.Count == 0)
                {
                    return BadRequest("No hay notificaciones para procesar.");
                }

                var notificacion = _colaNotificaciones.Desencolar();
                return Ok($"Notificación procesada: {notificacion.Mensaje}");
            }
            catch (Exception ex)
            {
                return StatusCode(500, "Se produjo un error al procesar las notificaciones.");
            }
        }
    }
    public class Notificacion
    {
        public int NumeroTarjeta { get; set; }
        public string Mensaje { get; set; }
    }
}