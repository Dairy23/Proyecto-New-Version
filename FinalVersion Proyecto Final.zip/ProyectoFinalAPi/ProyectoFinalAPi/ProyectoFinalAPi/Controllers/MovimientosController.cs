﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;
using Microsoft.AspNetCore.Mvc;
using ProyectoFinalAPi.Models;
using ProyectoFinalAPi;
using System;
using System.Collections.Generic;

namespace ProyectoFinalAPi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MovimientosController : ControllerBase
    {
        private readonly Pila<Movimiento> pilaMovimientos;
        private readonly JSON _json;
        private readonly List<TarjetaCredito> tarjetas = new List<TarjetaCredito>();

        public MovimientosController(Pila<Movimiento> pilaMovimientos, JSON json)
        {
            this.pilaMovimientos = pilaMovimientos;
            _json = json;
            Initialize();
        }
        private void Initialize()
        {
            try
            {
                string jsonFilePath = "misTarjetas.json"; // Nombre del archivo JSON
                var tarjetasDesdeJson = _json.CargarTarjetasDesdeJSON(jsonFilePath);
                tarjetas.AddRange(tarjetasDesdeJson);  // Agrega las tarjetas cargadas a la lista existente
            }
            catch (Exception ex)
            {
                // Manejar la excepción aquí, si es necesario
                Console.WriteLine($"Error al inicializar tarjetas de crédito: {ex.Message}");
            }
        }


        [HttpGet("{numeroTarjeta}")]
        public IActionResult ConsultarMovimientos(int numeroTarjeta)
        {
            var movimientos = pilaMovimientos.ObtenerTodos(m => m.NumeroTarjeta == numeroTarjeta);
            return Ok(movimientos);
        }
        // Método para registrar nuevos movimientos
        [HttpPost]
        public IActionResult RegistrarMovimiento([FromBody] Movimiento movimiento)
        {
            try
            {
                pilaMovimientos.Apilar(movimiento);
                return Ok("Movimiento registrado correctamente.");
            }
            catch (Exception ex)
            {
                return StatusCode(500, "Se produjo un error al registrar el movimiento.");
            }
        }
    }
}
